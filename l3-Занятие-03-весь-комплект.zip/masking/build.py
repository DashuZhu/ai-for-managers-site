from pathlib import Path
import hashlib,base64
p=Path(__file__).resolve().parent
core=(p/'core.mjs').read_text().replace('export ','')
script=core+'\n'+(p/'ui.js').read_text()
hash=base64.b64encode(hashlib.sha256(script.encode()).digest()).decode()
csp="default-src 'none'; script-src 'sha256-"+hash+"'; style-src 'unsafe-inline'; connect-src 'none'; img-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"
s=(p/'ui.html').read_text().replace('__CSP__',csp).replace('__SCRIPT__',script)
(p/'masking.html').write_text(s)
print('Self-contained HTML:',len(s.encode()),'bytes; script hash',hash)
