"""Run only in a connected preparation environment, with no meeting recordings."""
from huggingface_hub import snapshot_download
import sys
snapshot_download('Systran/faster-whisper-base',revision='ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66',local_dir=sys.argv[1],allow_patterns=['model.bin','config.json','tokenizer.json','vocabulary.*','preprocessor_config.json'])
print('Модель подготовлена. Проверьте хеши и перенесите каталог в согласованное место.')
