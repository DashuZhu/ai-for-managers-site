const enc=new TextEncoder(),dec=new TextDecoder();
const MAX=200000;
function checkText(text){if(typeof text!=='string'||text.length>MAX)throw Error('Нужен текст до 200 000 символов.');}
function rx(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function b64(a){const b=new Uint8Array(a);let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s);}
function bytes(s){if(typeof s!=='string'||s.length>1000000)throw Error('Некорректный файл.');return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
export function mask(text,values){checkText(text);if(text.includes('[[MASK_'))throw Error('В исходнике уже есть служебные обозначения [[MASK_. Начните с исходного текста.');
const clean=[...new Set(values.map(v=>v.trim()).filter(Boolean))];if(!clean.length||clean.length>100)throw Error('Добавьте от 1 до 100 точных фрагментов.');
for(const v of clean)if(v.length>1000||v.includes('[[MASK_'))throw Error('Некорректный фрагмент.');
const session=Array.from(crypto.getRandomValues(new Uint8Array(6)),b=>b.toString(16).padStart(2,'0')).join('');
const entries=clean.map((value,i)=>({token:`[[MASK_${session}_${String(i+1).padStart(3,'0')}]]`,value,count:0}));
const byValue=new Map(entries.map(e=>[e.value,e]));const pattern=new RegExp([...clean].sort((a,b)=>b.length-a.length).map(rx).join('|'),'gu');
const masked=text.replace(pattern,value=>{const e=byValue.get(value);e.count++;return e.token});
const used=entries.filter(e=>e.count>0);if(!used.length)throw Error('Ни один фрагмент не найден. Укажите точное написание из исходника.');
return {masked,map:{version:1,session,entries:used.map(({token,value})=>({token,value}))},stats:entries.map(({value,count})=>({value,count}))};}
export function validateMap(map){if(map?.version!==1||!/^[a-f0-9]{12}$/.test(map?.session||'')||!Array.isArray(map.entries)||!map.entries.length||map.entries.length>100)throw Error('Неверная таблица замен.');
const seen=new Set();for(const e of map.entries){if(!new RegExp('^\\[\\[MASK_'+map.session+'_\\d{3}\\]\\]$').test(e.token)||typeof e.value!=='string'||!e.value||e.value.length>1000||seen.has(e.token)||e.value.includes('[[MASK_'))throw Error('Неверная запись таблицы.');seen.add(e.token);}return map;}
export function restore(text,map){checkText(text);validateMap(map);const dict=new Map(map.entries.map(e=>[e.token,e.value]));const found=text.match(/\[\[MASK_[^\r\n]*?\]\]/g)||[];if(found.some(t=>!dict.has(t)))throw Error('В ответе есть неизвестные обозначения. Возможно, открыт другой справочник. Восстановление остановлено.');
const result=text.replace(/\[\[MASK_[^\r\n]*?\]\]/g,t=>dict.get(t));if(result.includes('[[MASK_'))throw Error('ИИ изменил обозначение. Проверьте его по маскированному тексту.');if(!found.length)throw Error('В ответе нет обозначений. Нечего восстанавливать.');return result;}
async function key(password,salt){if(typeof password!=='string'||password.length<12||password.length>1000)throw Error('Пароль: от 12 до 1000 символов.');const raw=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:310000,hash:'SHA-256'},raw,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);}
export async function seal(map,password){validateMap(map);const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));const k=await key(password,salt);const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:enc.encode('mask-vault-v1')},k,enc.encode(JSON.stringify(map)));return {format:'mask-vault-v1',kdf:'PBKDF2-SHA256',iterations:310000,salt:b64(salt),iv:b64(iv),cipher:b64(cipher)};}
export async function unseal(v,password){if(v?.format!=='mask-vault-v1'||v.kdf!=='PBKDF2-SHA256'||v.iterations!==310000)throw Error('Неподдерживаемый формат справочника.');const salt=bytes(v.salt),iv=bytes(v.iv),cipher=bytes(v.cipher);if(salt.length!==16||iv.length!==12||cipher.length<16||cipher.length>600000)throw Error('Повреждённый файл.');try{const k=await key(password,salt);const data=await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:enc.encode('mask-vault-v1')},k,cipher);return validateMap(JSON.parse(dec.decode(data)));}catch{throw Error('Справочник не открыт: неверный пароль или файл изменён.');}}
export function suggest(text){checkText(text);return [...new Set([...(text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[]),...(text.match(/\+7[ ()\d-]{10,20}\d/g)||[])])];}
