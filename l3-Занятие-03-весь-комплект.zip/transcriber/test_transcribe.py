import unittest,tempfile,wave,socket,subprocess,sys,json
from pathlib import Path
from transcribe import validate_audio,validate_model,save_exclusive
class Checks(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def wav(self,name='x.wav',frames=16000):
  p=self.p/name
  with wave.open(str(p),'wb') as w:w.setparams((1,2,16000,0,'NONE',''));w.writeframes(b'\0\0'*frames)
  return p
 def test_valid(self):self.assertEqual(validate_audio(self.wav())[1],1)
 def test_invalid(self):
  p=self.p/'bad.wav';p.write_text('not audio')
  with self.assertRaises(ValueError):validate_audio(p)
 def test_truncated(self):
  p=self.wav();p.write_bytes(p.read_bytes()[:-10])
  with self.assertRaises(ValueError):validate_audio(p)
 def test_duration(self):
  with self.assertRaises(ValueError):validate_audio(self.wav(frames=16000*301))
 def test_symlink(self):
  p=self.wav();q=self.p/'link.wav';q.symlink_to(p)
  with self.assertRaises(ValueError):validate_audio(q)
 def test_incomplete_model(self):
  with self.assertRaises(ValueError):validate_model(self.p)
 def test_no_overwrite(self):
  p=self.p/'out.json';save_exclusive(p,{'text':'учебное'})
  with self.assertRaises(FileExistsError):save_exclusive(p,{'text':'changed'})
  self.assertEqual(json.loads(p.read_text())['text'],'учебное')
  self.assertEqual(p.stat().st_mode&0o777,0o600)
 def test_python_network_block(self):
  r=subprocess.run([sys.executable,'-c',"import sys,socket;from transcribe import block_python_network;sys.addaudithook(block_python_network);socket.create_connection(('example.com',443))"],capture_output=True,text=True,cwd=Path(__file__).parent)
  self.assertNotEqual(r.returncode,0);self.assertIn('Network calls are disabled',r.stderr)
if __name__=='__main__':unittest.main()
