"""Offline teaching CLI. No cloud fallback. WAV only; not a multiuser server."""
import argparse, hashlib, io, json, os, sys, wave
from pathlib import Path
MAX_BYTES=20*1024*1024
MAX_SECONDS=300

def block_python_network(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo'}:
        raise PermissionError('Network calls are disabled in this process')

def validate_audio(path):
    if path.is_symlink() or not path.is_file():raise ValueError('Нужен обычный WAV-файл, без символической ссылки.')
    if path.stat().st_size>MAX_BYTES:raise ValueError('Файл больше 20 МиБ.')
    data=path.read_bytes()
    if len(data)>MAX_BYTES:raise ValueError('Файл больше 20 МиБ.')
    try:
        with wave.open(io.BytesIO(data),'rb') as w:
            rate=w.getframerate();frames=w.getnframes()
            if w.getcomptype()!='NONE' or w.getsampwidth()!=2 or w.getnchannels() not in [1,2] or rate not in [16000,44100,48000]:
                raise ValueError('Нужен PCM WAV, 16 bit, mono/stereo, 16 / 44,1 / 48 кГц.')
            seconds=frames/rate
            if not 0<seconds<=MAX_SECONDS:raise ValueError('Допустима запись от 0 до 300 секунд.')
            expected=frames*w.getnchannels()*w.getsampwidth()
            if len(w.readframes(frames))!=expected:raise ValueError('WAV обрезан или повреждён.')
    except (wave.Error,EOFError) as exc:raise ValueError('Не удалось прочитать PCM WAV.') from exc
    return data,seconds

def validate_model(path):
    path=path.resolve(strict=True)
    if not path.is_dir() or any(not (path/f).is_file() for f in ['model.bin','config.json','tokenizer.json']):
        raise ValueError('Нужна полная локальная модель CTranslate2: model.bin, config.json, tokenizer.json.')
    return path

def save_exclusive(path,result):
    payload=json.dumps(result,ensure_ascii=False,indent=2).encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(payload)

def main():
    p=argparse.ArgumentParser(description='Локальная расшифровка учебной WAV-записи. Результат содержит открытый текст.')
    p.add_argument('--model',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:
        os.umask(0o077)
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',DO_NOT_TRACK='1')
        sys.addaudithook(block_python_network)
        data,seconds=validate_audio(a.input);model_path=validate_model(a.model)
        if a.out.exists():raise ValueError('Выходной файл уже существует. Выберите новое имя.')
        from faster_whisper import WhisperModel
        model=WhisperModel(str(model_path),device='cpu',compute_type='int8',local_files_only=True,cpu_threads=4,num_workers=1)
        chunks,info=model.transcribe(io.BytesIO(data),language='ru',beam_size=5,vad_filter=False,condition_on_previous_text=False)
        segments=[{'start':round(s.start,2),'end':round(s.end,2),'text':s.text.strip()} for s in chunks]
        result={'notice':'Черновик ASR: сверьте имена, суммы, сроки и решения с записью. Разделения по говорящим нет.','input_sha256':hashlib.sha256(data).hexdigest(),'duration_seconds':round(seconds,2),'language':info.language,'segments':segments,'text':' '.join(s['text'] for s in segments)}
        save_exclusive(a.out,result)
        print(f'Готово. Длительность: {seconds:.1f} с. Фрагментов: {len(segments)}. Результат записан в указанный локальный файл.')
        return 0
    except Exception as exc:
        # Avoid disclosing transcript or filesystem paths through tracebacks/logs.
        print('Обработка остановлена. '+(str(exc) if isinstance(exc,ValueError) else 'Проверьте локальную модель, зависимости и права. Облачной отправки не было.'),file=sys.stderr)
        return 1
if __name__=='__main__':sys.exit(main())
